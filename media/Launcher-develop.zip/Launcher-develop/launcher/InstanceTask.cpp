#include "InstanceTask.h"

InstanceTask::InstanceTask()
{
}

InstanceTask::~InstanceTask()
{
}
